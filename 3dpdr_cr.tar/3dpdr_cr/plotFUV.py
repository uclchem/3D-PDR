import numpy as np
import matplotlib.pyplot as plt

dat = np.loadtxt("testFUV.dat")
plt.semilogy(dat[:,0], dat[:,1])
plt.show()
